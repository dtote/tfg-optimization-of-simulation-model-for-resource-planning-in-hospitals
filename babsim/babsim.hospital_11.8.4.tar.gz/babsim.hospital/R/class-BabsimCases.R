DailyCases <- function(data, from, to) {}
